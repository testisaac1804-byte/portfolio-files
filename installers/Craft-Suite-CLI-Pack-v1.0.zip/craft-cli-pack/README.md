# Craft Suite CLI Pack (v1.0, 2026-10-23)

Everything needed to drive the 13 **ArtCraft "Crafting Apps"** headlessly on macOS — plus the
receipts for what was actually tested on this machine.

The desktop apps are only half the product. Each one also exposes its **entire command registry**
to a separate `<app>-cli` binary, a JSON control channel and an MCP server. That binary ships as its
own release asset and **the app and the official launcher do not install it**, which is why the
apps feel scriptable but nothing is on your `PATH`.

## What's in this pack

| File | What it is |
|---|---|
| `craft-cli-install.sh` | Downloads, unpacks, de-quarantines and symlinks all 13 `<app>-cli` binaries into `~/.local/bin`. Resumable (`curl -C -`), safe to re-run. |
| `craft-cli-verify.sh` | Smoke-tests every CLI: version, command count, one functional check. Exit code 0 = all respond. |
| `MANIFEST.json` | Machine-readable: each app, repo, what it replaces, stars, CLI version, command count, disk size, what was verified, status. |
| `OFFICIAL-LINKS.md` | The only download links worth using — official site, launcher, per-app repos. |

## Install

```bash
unzip Craft-Suite-CLI-Pack-v1.0.zip && cd craft-cli-pack
chmod +x craft-cli-install.sh craft-cli-verify.sh
./craft-cli-install.sh            # all 13 (about 1.7 GB of downloads)
./craft-cli-verify.sh             # expect "All 13 CLIs respond."
```

Subsets work too: `./craft-cli-install.sh pdfcraft vectorcraft cadcraft gridcraft` is ~250 MB.

Requirements: macOS on Apple silicon or Intel (the assets are universal binaries), ~2 GB of disk
for all 13, and `~/.local/bin` on your `PATH`.

## Measured numbers (this Mac, 2026-10-23)

| | |
|---|---|
| Apps | 13 |
| CLI command entries | **6,986** |
| Installed size | **1.76 GB** |
| Combined GitHub stars | 180,059 |
| PDF page render | A1 poster → PNG in **12 ms** |
| `.docx` → PDF | 6-page CJK document in **0.21 s** |
| `.pptx` → PNG | one slide in **0.34 s** |
| `.xlsx` with real formulas | written, recomputed and verified |

## Three things worth knowing before you trust it

1. **This is not cracked Adobe.** These are clean-room reimplementations in pure Rust under
   MIT/Apache-2.0. The repos' contribution rules forbid copying code, shaders, icons or ICC profiles
   from proprietary software. Checked against the installed PhotoCraft binary: no Adobe libraries,
   no `.8bf` plug-ins, no ICC files, no Adobe copyright strings — only the file-format namespaces a
   PSD reader is legally obliged to speak (`8BIM`, XMP, "Adobe RGB (1998) compatible").
2. **AI was involved, heavily.** The repos ship `AGENTS.md` ("guide for AI agents and contributors")
   and `.claude` rules, and target 1:1 menu/shortcut parity with Photoshop. That is why it looks and
   feels pirated. It is reimplementation at agent speed, not theft.
3. **Everything is alpha.** PhotoCraft, PdfCraft and FigCraft still say "early alpha". Treat output as
   drafts: keep the originals, export to a new filename, and don't let a 0.x app be the only copy of
   anything you care about. PdfCraft's saves are append-only, which is safer than most.

## Highest-value commands

```bash
pdfcraft-cli render in.pdf --page 1 --dpi 150 --out p1.png     # no browser, no pdftoppm
pdfcraft-cli audit in.pdf                                      # finds FAUX redactions
gridcraft-cli check out.xlsx                                   # formula + round-trip oracle
wordcraft-cli convert doc.docx out.pdf --markup                # comments/tracked changes drawn in
vectorcraft-cli convert art.svg outlined.svg --outline-text    # LightBurn-safe text
cadcraft-cli convert part.dxf part.svg                         # Fusion 360 -> laser
deckcraft-cli render deck.pptx --all slides/                   # every slide as PNG
```

Find any command id instead of guessing: `<app>-cli commands | grep -i <thing>`.
Register one as an agent tool: `<app>-cli mcp` (stdio MCP server).

## Credits

Apps by **storytold** (<https://github.com/storytold>) — MIT OR Apache-2.0. This pack is a set of
install/verify scripts plus measurements, MIT. Not affiliated with Adobe, Microsoft, Autodesk,
Avid or Figma.
