#!/bin/bash
# Smoke-test every Craft CLI: version, command count, one functional check.
# Exit code = number of failing apps (0 = all good).
#
#   ./craft-cli-verify.sh
#
# "CMDS" is the number of entries in the CLI's own `commands` listing.
# Apps differ in format: some print JSON (count the array), some print a plain
# listing with the command id at column 0 and its parameter docs indented on the
# following line (count the column-0 lines). Python 3 does the JSON case and is
# optional — without it the plain-listing count is used for everything.
#
# macOS has no `timeout` command, so each call is guarded with a perl alarm.
set -uo pipefail

APPS="photocraft pdfcraft filmcraft lightcraft vectorcraft effectcraft cadcraft gridcraft designcraft deckcraft wordcraft soundcraft figcraft"
fail=0
printf '%-14s %-24s %-7s %s\n' APP VERSION CMDS CHECK

tmo() { perl -e 'alarm shift; exec @ARGV' "$@"; }

count_ids() {   # stdin: a `commands` (or `tools`) listing
  local content n
  content=$(cat)
  n=$(printf '%s' "$content" | python3 -c '
import json, sys
raw = sys.stdin.read().strip()
if not raw:
    print(0); sys.exit()
try:
    d = json.loads(raw)
except Exception:
    print(sum(1 for l in raw.splitlines() if l.strip() and l[:1] not in (" ", "\t")))
else:
    if isinstance(d, list): print(len(d))
    elif isinstance(d, dict):
        for k in ("commands", "tools", "items"):
            if isinstance(d.get(k), list): print(len(d[k])); break
        else: print(len(d))
    else: print(0)
' 2>/dev/null)
  if [ -z "$n" ]; then    # no usable python3: fall back to column-0 lines
    n=$(printf '%s\n' "$content" | awk 'NF && $0 !~ /^[ \t]/' | wc -l | tr -d ' ')
  fi
  [ -z "$n" ] && n=0
  printf '%s' "$n"
}

for a in $APPS; do
  bin="$HOME/.local/bin/$a-cli"
  if [ ! -x "$bin" ]; then printf '%-14s %s\n' "$a" "MISSING ($bin)"; fail=$((fail+1)); continue; fi
  ver=$(tmo 20 "$bin" --version 2>&1 | head -1 | cut -c1-24)
  tmp=$(mktemp)
  if tmo 40 "$bin" commands >"$tmp" 2>/dev/null && [ -s "$tmp" ]; then
    ids=$(count_ids < "$tmp")
  else
    ids=0
  fi
  if [ "$ids" -eq 0 ] && tmo 40 "$bin" tools >"$tmp" 2>/dev/null && [ -s "$tmp" ]; then
    ids=$(count_ids < "$tmp")
  fi
  rm -f "$tmp"
  case "$a" in
    gridcraft) c=$(tmo 15 "$bin" eval '=SUM(1,2,3)*2' 2>&1 | tr -d '\n') ;;
    pdfcraft)  c=$(tmo 20 "$bin" info --help 2>/dev/null | head -1 | cut -c1-30); [ -z "$c" ] && c="answers CLI" ;;
    *)         c="answers CLI" ;;
  esac
  [ -z "$ver" ] && { ver="NO RESPONSE"; fail=$((fail+1)); }
  printf '%-14s %-24s %-7s %s\n' "$a" "$ver" "${ids:-?}" "$c"
done

echo
if [ "$fail" -eq 0 ]; then echo "All 13 CLIs respond."; else echo "$fail app(s) failed."; fi
exit "$fail"
