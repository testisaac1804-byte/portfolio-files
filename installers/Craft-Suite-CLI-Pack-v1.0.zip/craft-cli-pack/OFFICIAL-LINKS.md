# Official links — the only ones worth using

Everything below is the projects' own infrastructure. Avoid "AI-cracked Adobe" repacks found on
social media: cracked Creative Cloud installers are a leading delivery route for macOS infostealers,
and none of this software needs one.

## Project

| What | Link |
|---|---|
| Homepage | <https://getartcraft.com/> |
| All 13 apps (list + descriptions) | <https://getartcraft.com/apps> |
| AI image/video studio, web version | <https://app.getartcraft.com/> |
| Desktop launcher (official DMG) | <https://github.com/storytold/craft-launcher/releases> |
| GitHub organisation | <https://github.com/storytold> |

Note: `getartcraft.com/app` is a 404 (the real web studio is `app.getartcraft.com`), and the
"Download Launcher" button on `/apps` currently hands out a **Linux `.flatpak`** even on a Mac. Take
the DMG from the launcher release page instead: `artcraft-launcher-<ver>-macos-universal.dmg`.

## Per-app repos (releases carry the GUI *and* the CLI assets)

| App | Replaces | Repo |
|---|---|---|
| PhotoCraft | Photoshop | <https://github.com/storytold/photocraft> |
| PdfCraft | Acrobat | <https://github.com/storytold/pdfcraft> |
| FilmCraft | Premiere Pro | <https://github.com/storytold/filmcraft> |
| LightCraft | Lightroom | <https://github.com/storytold/lightcraft> |
| VectorCraft | Illustrator | <https://github.com/storytold/vectorcraft> |
| EffectCraft | After Effects | <https://github.com/storytold/effectcraft> |
| CADCraft | AutoCAD | <https://github.com/storytold/cadcraft> |
| GridCraft | Excel | <https://github.com/storytold/gridcraft> |
| DesignCraft | InDesign | <https://github.com/storytold/designcraft> |
| DeckCraft | PowerPoint | <https://github.com/storytold/deckcraft> |
| WordCraft | Word | <https://github.com/storytold/wordcraft> |
| SoundCraft | Pro Tools | <https://github.com/storytold/soundcraft> |
| FigCraft | Figma | <https://github.com/storytold/figcraft> |

## CLI asset URL pattern

```
https://github.com/storytold/<app>/releases/download/v<ver>/<app>-cli-<ver>-macos-universal.zip
```

Get the current version for any app without scraping:

```bash
curl -s https://api.github.com/repos/storytold/<app>/releases/latest | grep -m1 '"tag_name"'
```

`craft-cli-install.sh` in this pack already pins the versions measured on 2026-10-23; edit its
`ver_of()` block when a release moves.

## What "free" actually means

The **software** is free and open source (MIT OR Apache-2.0) — no subscription, no account, no
licence server. The **AI models** are a separate matter: ArtCraft desktop expects your own
Midjourney subscription or a fal API key, and the web studio runs on account credits. The 13
Crafting Apps themselves need no account at all.
