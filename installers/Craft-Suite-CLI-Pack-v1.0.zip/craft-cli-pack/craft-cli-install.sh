#!/bin/bash
# Install the ArtCraft / Crafting Apps CLIs (the agent + MCP front doors) on macOS.
#
#   ./craft-cli-install.sh              # all 13 apps
#   ./craft-cli-install.sh pdfcraft     # just one
#   ./craft-cli-install.sh pdfcraft gridcraft vectorcraft cadcraft
#
# Downloads each `<app>-cli` release asset with resume, extracts to
# ~/.local/craft-cli/<app>, strips the quarantine bit, and symlinks
# <app>-cli into ~/.local/bin (create it and add it to PATH if missing).
#
# Written for macOS /bin/bash 3.2: no associative arrays, no ${var,,}.
# Versions measured 2026-10-23 against github.com/storytold/<app>/releases.
set -uo pipefail

DEST="$HOME/.local/craft-cli"
BIN="$HOME/.local/bin"
TMP="$DEST/_zips"
mkdir -p "$BIN" "$TMP"

ver_of() {
  case "$1" in
    photocraft)   echo 0.12.0 ;;
    pdfcraft)     echo 0.11.0 ;;
    vectorcraft)  echo 0.14.0 ;;
    cadcraft)     echo 0.10.0 ;;
    gridcraft)    echo 0.10.0 ;;
    wordcraft)    echo 0.9.0  ;;
    deckcraft)    echo 0.9.0  ;;
    soundcraft)   echo 0.11.0 ;;
    filmcraft)    echo 0.10.0 ;;
    effectcraft)  echo 0.14.0 ;;
    designcraft)  echo 0.11.0 ;;
    figcraft)     echo 0.9.0  ;;
    lightcraft)   echo 0.11.0 ;;
    *) echo "" ;;
  esac
}

APPS=("$@")
if [ ${#APPS[@]} -eq 0 ]; then
  APPS=(photocraft pdfcraft filmcraft lightcraft vectorcraft effectcraft cadcraft \
        gridcraft designcraft deckcraft wordcraft soundcraft figcraft)
fi

for app in "${APPS[@]}"; do
  v="$(ver_of "$app")"
  if [ -z "$v" ]; then echo "!! unknown app: $app"; continue; fi
  name="${app}-cli-${v}-macos-universal"
  url="https://github.com/storytold/${app}/releases/download/v${v}/${name}.zip"
  zip="$TMP/${name}.zip"
  echo "==> ${app} ${v}"
  # -C - resumes a partial file; --retry rides out flaky wifi
  curl -fL -C - --retry 8 --retry-delay 3 --retry-all-errors \
       --connect-timeout 20 -o "$zip" "$url" || { echo "!! download failed: $app"; continue; }
  rm -rf "$DEST/$app"; mkdir -p "$DEST/$app"
  unzip -q -o "$zip" -d "$DEST/$app" || { echo "!! unzip failed: $app"; continue; }
  exe=$(find "$DEST/$app" -type f -perm -u+x -name "${app}-cli" | head -1)
  if [ -z "$exe" ]; then
    exe=$(find "$DEST/$app" -type f -perm -u+x -maxdepth 3 ! -name "*.dylib" ! -name "*.txt" | head -1)
  fi
  if [ -z "$exe" ]; then echo "!! no binary found for $app"; continue; fi
  chmod +x "$exe"
  xattr -dr com.apple.quarantine "$DEST/$app" 2>/dev/null || true
  ln -sf "$exe" "$BIN/${app}-cli"
  echo "    installed -> $BIN/${app}-cli"
  rm -f "$zip"
done

echo "--- installed CLIs ---"
ls -l "$BIN"/*-cli 2>/dev/null | awk '{print $9, "->", $11}'
